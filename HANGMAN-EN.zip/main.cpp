/***********************************************************
NAME: Barbara Luciano Araujo
DATE: June 21, 2020
ASSIGNMENT: Summative Project
DESCRIPTION: Users can play the game hangman and choose the game theme
CONCEPTS: Switch Statements, If Statements, Functions, Arrays, Strings, Cfail, Random computer choice, For loop, Do/while loop, While loop.
FUNCTIONS:
function_country, function_colour, function_fruit, function_animal, function_schoolSubject, function_sports, function_clothes - function to make the game with the chosen theme
letterFill - function to fill the word
***********************************************************/
 
#include <iostream>
#include<ctime>
#include <string>
#include <iomanip>
using namespace std;
 
// ---- strings to hold the words for the game ----
 
int const array_size = 41; //size of string for names of countries
//string for names of countries
string array_country[array_size] = {"argentina", "australia", "brazil", "belgium", "canada", "china", "chile", "colombia", "denmark", "ecuador", "egypt", "france", "germany", "greece", "haiti", "india", "italy", "japan", "kenya", "lebanon", "madagascar", "maldives", "mexico", "nepal", "newzealand", "nigeria", "panama", "paraguay", "peru", "portugal", "russia", "romania", "saudiarabia", "senegal", "sweden", "switzerland", "turkey", "uruguay", "venezuela", "vietnam", "zambia"};
string countryword;//string for hold the chosen country word
 
int const array_size2 = 15;//size of string for names of colours
//string for hold the names of colours
string array_colour[array_size2] = {"blue", "pink", "yellow", "red", "orange", "purple", "white", "black", "brown", "gray", "green", "navy", "beige", "gold", "silver"};
string colourword;//string for hold the chosen colour word
 
int const array_size3 = 27;//size of string for names of fruits
// string for hold the names of fruits
string array_fruit[array_size3] = {"apple", "avocado", "banana", "blueberry", "cherry", "cucumber", "dewberry", "fig", "grapes", "guava", "jackfruit", "kiwi", "lemon", "mango", "melon", "nectarine", "olive", "orange", "papaya", "peach", "pear", "pineapple", "raspberry", "strawberry", "tangerine", "tomato", "watermelon"};
string fruitword;//string for for hold the chosen fruit word
 
int const array_size4 = 61;//size of string for names of animals
string array_animal[array_size4] = {"ant", "bat", "bear", "bird", "coyote", "crab", "crocodile", "cougar", "deer", "duck", "dog", "dolphin", "eagle", "elephant", "falcon", "flamingo", "fox", "fish", "frog", "gazelle", "giraffe", "goat", "goose", "gorilla", "gull", "hippopotamus", "iguana", "jaguar", "kangaroo", "koala", "leopard", "lion", "lizard", "llama", "mockingbird", "monkey", "moose", "mouse", "otter", "owl", "platypus", "pelican", "penguin", "pigeon", "polarbear", "possum", "rabbit", "rat", "raven", "reindeer", "salmon", "seal", "sheep", "snake", "squirrel", "swan", "tiger", "turkey", "whale", "wolf", "zebra"};//string for names of animals
string animalword;//string for for hold the chosen animal word
 
int const array_size5 = 26; //size of string for names of school subject
string array_schoolSubject [array_size5] = { "arts", "mathematics", "science", "fitness", "music", "drama", "dance", "spanish", "french", "english", "geography", "sociology", "anthropology", "psychology", "history", "programming", "economics", "literature", "composition", "poetry", "photography", "physics", "chemistry", "biology", "civics", "culinary" };//string for names of school subject
string schoolSubjectword; //string for for hold the chosen school subject word
 
const int array_size6 = 32; //size of string for names of sports
string array_sports [array_size6] = { "athletics", "archery", "badminton", "baseball", "biking", "bowling", "basketball", "boxing", "curling", "canoeing", "dodgeball", "football", "frisbee", "golfing", "hockey", "handball", "run", "judo", "karate", "lacrosse", "paintball", "pingpong", "soccer", "squash", "swimming", "surfing", "snowboarding", "skating", "taekwondo", "tennis", "wakeboarding", "weightlifting"}; //string for names of sports
string sportsword;//string for for hold the chosen sports word
 
const int array_size7 = 39;//size of string for names of clothes
string array_clothes [array_size7] = { "belt", "bra", "bikini", "boot", "blazer", "bandana", "cap", "coat", "dress", "flip-flops", "gloves", "hat", "heels", "helmet", "hoodie", "jersey", "jeans", "jacket", "leggings", "lingerie", "pajamas", "pants", "robe", "sandals", "scarf", "shirt", "skirt", "slippers", "sneakers", "sweater", "suit", "sock", "smock", "shorts", "tie", "top", "tiara", "uniform", "underwear" }; //string for names of clothes
string clothesword; //string for for hold the chosen clothes word
 
// ----- end of strings -----
 
 
//initializing the maximum of wrong guesses the user can input
const int max_trials = 6;
 
 
// ------  functions for each theme ------
 
//initializing the function to fill the word
int letterFill (char, string, string&);
 
//function for make the game if the chosen theme is country
void function_country (int choose_country, int wrong_guess, char letter, int& wins, int& losses);//initializing the function
void function_country (int choose_country, int wrong_guess, char letter, int& wins, int& losses)//void function because it doesn't return to anything
{
 srand(time(NULL)); //for randomly choose the word and not repeat the same one all the time
 choose_country = rand() % 41;//for randomly choose the word from the string
 countryword = array_country[choose_country];//for choose the word in the string
 string unknown(countryword.length(),'-');//initializing the string for hold the word into characters
 
 while (wrong_guess < max_trials)//while loop for make the game run at least once and repeat until the number of wrong guesses is equal to the number of maximum trials, which is 6 (one for each part of the hangman's body)
 {
   cout << "\n\t\t" << unknown << endl;//output the word in characters
 
   do//do/while loop for repeat until the user inputs a letter and not a character, a number or a capitalized letter
   {
   cout << "Guess a letter: ";//output the space for the user input a letter
   cin >> letter;//user input
 
   //if statement for output the user error
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   //if/else if statement for check if the user letter is in word or not
   if (letterFill(letter, countryword, unknown) == 0)//for if the letter is in the word
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else //for if the letter is not in the word
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   //if statement for check if the user won the game
   if (countryword == unknown)//for if the user guess all the letters
   {
     cout << "\n\n\t\t" << countryword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;//for count the number of wins
     break;
   }
 
 }
 //if statement for check if the user doesn't have any more guesses
 if (wrong_guess == max_trials)//for output that the user lost
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was  --- " << countryword << "  ---" << endl;
   losses++;//for count the number of losses
 }
}
 
//function for make the game if the chosen theme is colour (same code as with the country theme)
void function_colour (int choose_colour, int wrong_guess, char letter, int& wins, int& losses);
void function_colour (int choose_colour, int wrong_guess, char letter, int& wins, int& losses)
{
 srand(time(NULL));
 choose_colour = rand() % 15;
 colourword = array_colour[choose_colour];
 string unknown(colourword.length(),'-');
 
 while (wrong_guess < max_trials)
 {
   cout << "\n\t\t" << unknown << endl;
 
   do
   {
   cout << "Guess a letter: ";
   cin >> letter;
 
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   if (letterFill(letter, colourword, unknown) == 0)
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   if (colourword == unknown)
   {
     cout << "\n\n\t\t" << colourword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;
     break;
   }
 
 }
 
 if (wrong_guess == max_trials)
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was  --- " << colourword << "  ---" << endl;
   losses++;
 }
 
}
 
//function for make the game if the chosen theme is colour (same code as with the country and colour theme)
void function_fruit (int choose_fruit, int wrong_guess, char letter, int& wins, int& losses);
void function_fruit (int choose_fruit, int wrong_guess, char letter, int& wins, int& losses)
{
 srand(time(NULL));
 choose_fruit = rand() % 27;
 fruitword = array_fruit[choose_fruit];
 string unknown(fruitword.length(),'-');
 
 while (wrong_guess < max_trials)
 {
   cout << "\n\t\t" << unknown << endl;
 
   do
   {
   cout << "Guess a letter: ";
   cin >> letter;
 
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   if (letterFill(letter, fruitword, unknown) == 0)
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   if (fruitword == unknown)
   {
     cout << "\n\n\t\t" << fruitword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;
     break;
   }
 
 }
 
 if (wrong_guess == max_trials)
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was  --- " << fruitword << "  ---" << endl;
   losses++;
 }
}
 
//function for make the game if the chosen theme is colour (same code as with the country, colour and fruit theme)
void function_animal (int choose_animal, int wrong_guess, char letter, int& wins, int& losses);
void function_animal (int choose_animal, int wrong_guess, char letter, int& wins, int& losses)
{
 srand(time(NULL));
 choose_animal = rand() % 61;
 animalword = array_animal[choose_animal];
 string unknown(animalword.length(),'-');
 
 while (wrong_guess < max_trials)
 {
   cout << "\n\t\t" << unknown << endl;
 
   do
   {
   cout << "Guess a letter: ";
   cin >> letter;
 
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   if (letterFill(letter, animalword, unknown) == 0)
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   if (animalword == unknown)
   {
     cout << "\n\n\t\t" << animalword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;
     break;
   }
 
 }
 
 if (wrong_guess == max_trials)
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was  --- " << animalword << "  ---" << endl;
   losses++;
 }
}
 
//function for make the game if the chosen theme is school subject (same code as with the country, colour, fruit and animal theme)
void function_schoolSubject (int choose_schoolSubject, int wrong_guess, char letter, int& wins, int& losses);
void function_schoolSubject (int choose_schoolSubject, int wrong_guess, char letter, int& wins, int& losses)
{
 srand(time(NULL));
 choose_schoolSubject = rand() % 26;
 schoolSubjectword = array_schoolSubject[choose_schoolSubject];
 string unknown(schoolSubjectword.length(),'-');
 
 while (wrong_guess < max_trials)
 {
   cout << "\n\t\t" << unknown << endl;
 
   do
   {
   cout << "Guess a letter: ";
   cin >> letter;
 
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   if (letterFill(letter, schoolSubjectword, unknown) == 0)
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   if (schoolSubjectword == unknown)
   {
     cout << "\n\n\t\t" << schoolSubjectword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;
     break;
   }
 
 }
 
 if (wrong_guess == max_trials)
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was --- " << schoolSubjectword << "  ---" << endl;
   losses++;
 }
}
 
//function for make the game if the chosen theme is sports (same code as with the country, colour, fruit, animal and school subject theme)
void function_sports (int choose_sports, int wrong_guess, char letter, int& wins, int& losses);
void function_sports (int choose_sports, int wrong_guess, char letter, int& wins, int& losses)
{
 srand(time(NULL));
 choose_sports = rand() % 32;
 sportsword = array_sports[choose_sports];
 string unknown(sportsword.length(),'-');
 
 while (wrong_guess < max_trials)
 {
   cout << "\n\t\t" << unknown << endl;
 
   do
   {
   cout << "Guess a letter: ";
   cin >> letter;
 
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   if (letterFill(letter, sportsword, unknown) == 0)
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   if (sportsword == unknown)
   {
     cout << "\n\n\t\t" << sportsword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;
     break;
   }
 
 }
 
 if (wrong_guess == max_trials)
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was  --- " << sportsword << "  ---" << endl;
   losses++;
 }
}
 
//function for make the game if the chosen theme is clothes (same code as with the country, colour, fruit, animal, school and sports subject theme)
void function_clothes (int choose_clothes, int wrong_guess, char letter, int& wins, int& losses);
void function_clothes (int choose_clothes, int wrong_guess, char letter, int& wins, int& losses)
{
 srand(time(NULL));
 choose_clothes = rand() % 39;
 clothesword = array_clothes[choose_clothes];
 string unknown(clothesword.length(),'-');
 
 while (wrong_guess < max_trials)
 {
   cout << "\n\t\t" << unknown << endl;
 
   do
   {
   cout << "Guess a letter: ";
   cin >> letter;
 
   if (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z')
   {
     cout << "\nOps! Not a letter or a capitalized letter! Try again!" << endl;
   }
   }
   while (letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd' && letter != 'e' && letter != 'f' && letter != 'g' && letter != 'h' && letter != 'i' && letter != 'j' && letter != 'k' && letter != 'l' && letter != 'm' && letter != 'n' && letter != 'o' && letter != 'p' && letter != 'q' && letter != 'r' && letter != 's' && letter != 't' && letter != 'u' && letter != 'v' && letter != 'w' && letter != 'x' && letter != 'y' && letter != 'z');
 
   if (letterFill(letter, clothesword, unknown) == 0)
   {
     cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
     wrong_guess++;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   else
   {
     cout << "\nUhull! This word has the letter " << letter << "." << endl;
     cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
     cout << "\n\t _______________________________" << endl;
   }
 
   if (clothesword == unknown)
   {
     cout << "\n\n\t\t" << clothesword << endl;
     cout << "\nYay!! You got the word!! Nice job!!" << endl;
     wins++;
     break;
   }
 
 }
 
 if (wrong_guess == max_trials)
 {
   cout << "\n Oh no! The number of wrong guesses is over! \n You are completely hanged! \n You lost! Maybe you will have better luck next time!" << endl;
   cout << "\n The word was  --- " << clothesword << "  ---" << endl;
   losses++;
 }
}
 
//  ------- end of functions -------
 
int main()
{
 
 
 // -------- initializing variables --------
 
 //initializing the variables for the words with the themes animal, country, colour or fruit
 char animal, fruit, colour, country, schoolSubject, sports, clothes;
 
 //initializing the variable for the user's inputs of play again, guess a letter and choose the theme
 char play_again, letter;
 int theme;
 
 //initializing the variables the will count something; the number of wrong guesses, wins and losses
 int wrong_letter = 0, wins = 0, losses = 0;
 
 //initializing the variable that will check for fail input
 bool cfail;
 
 //initializing all the strings of word for each theme again so they can be used inside the main stream
 string animalword;
 string fruitword;
 string colourword;
 string countryword;
 string schoolSubjectword;
 string sportsword;
 string clothesword;
 //  ---------- end of initializing variables ----------
 
 
 //  --------- introduction ---------
 
 //welcoming the user
 cout << "\n\n" << "--------------- Welcome to Hangman Game! ---------------" << endl;
 
 //outputting the ASCII of the hangman drawing
 cout << "\t\t\t\t\t " << "  ________   " << endl;
 cout << "\t\t\t\t\t " << "  |      |   " << endl;
 cout << "\t\t\t\t\t " << "  |      O  " << endl;
 cout << "\t\t\t\t\t " << "  |    - | - " << endl;
 cout << "\t\t\t\t\t " << "  |      |   " << endl;
 cout << "\t\t\t\t\t " << "  |    _ | _ " << endl;
 cout << "\t\t\t\t\t " << "  |          " << endl;
 cout << "\t\t\t\t\t " << "  |          " << endl;
 cout << "\t\t\t\t\t " << " ---         " << endl;
 
 //giving the game instructions
 cout << "\n\t\tInstructions: " << endl;
 cout << "1- Choose the theme you want to guess a word." << endl;
 cout << "2- Guess a letter." << endl;
 cout << "\tIf you guess a right letter, nothing happens with your \nhangman and your letter shows up in the secret word. " << endl;
 cout << "\tIf your letter is not in the word, you start to \nbe hanged, and when you make 6 mistakes, you will be \ncompletely hanged and lose the game. " << endl;
 cout << "3- Your goal is to make as less mistakes as possible \nand guess the word before you are completely hanged. " << endl;
 
 //  --------- end of introduction ---------
 
 //  ------------  the game  ------------
 
 //do/while loop for loop if the user answers to play again
 do
 {
   // ------- choice of theme -------
 
   //output the theme options for the user
   cout << "\n\tChoose a theme: " << "\n1 - Country" << "\n2 - Colour" << "\n3 - Fruit" << "\n4 - Animal" << "\n5 - School Subject" << "\n6 - Sports" << "\n7 - Clothes"<< endl;
 
   //do/while loop for loop if the user inputs a number higher than 6, a letter or a character
   do
   {
     //cin fail for the user's wrong input
     cin >> theme;
     cfail = cin.fail();
     cin.clear();
     cin.ignore(numeric_limits<streamsize> :: max(), '\n');
 
     //if statement for output the user error
     if ( cfail == true || theme >= 8 || theme<= 0)
     {
       cout << "\nInvalid answer. Please insert numbers between 1 and 7." << endl;
       cout << "You answer: ";
     }
   }
   while (cfail == true || theme >= 8 || theme<= 0);
 
 // ------- end of choice of theme -------
 
 //bringing the randomization into the main stream
 srand(time(NULL));
 animal = rand() % 61;
 fruit = rand() % 27;
 colour = rand() % 15;
 country = rand() % 41;
 schoolSubject = rand() % 26;
 sports = rand() % 35;
  //switch statement for the user's choice of theme
 switch (theme)
 {
   case 1: //if the user chooses 1 for a country word
   function_country(country, wrong_letter, letter, wins, losses);//calling the country word function
   break;
   case 2: //if the user chooses 2 for a colour word
   function_colour(colour, wrong_letter, letter, wins, losses); //calling the colour word function
   break;
   case 3: //if the user chooses 3 for a fruit word
   function_fruit(fruit, wrong_letter, letter, wins, losses); //calling the fruit word function
   break;
   case 4: //if the user chooses 4 for an animal word
   function_animal(animal, wrong_letter, letter, wins, losses); //calling the animal word function
   break;
   case 5:
   function_schoolSubject(schoolSubject, wrong_letter,letter, wins, losses);
   break;
   case 6:
   function_sports(sports, wrong_letter,letter, wins, losses);
   break;
   case 7:
   function_clothes(clothes, wrong_letter,letter, wins, losses);
   break;
 }
 
 // ------------ end of the game -----------
 
 //ask the user if wants to play again
 cout << "\n\nWould you like to play again? " << endl;
 cout << "Input y for yes or n for no. " << endl;
  //do/while loop for if the user inputs something different than y or n
 do
 {
 cin >> play_again;//user input
  //if statement for output the user error
 if (play_again != 'y' && play_again != 'Y' && play_again != 'n' && play_again != 'N')
 {
   cout << "\nError! Invalid answer! Please input y for yes or n for no." << endl;
   cout << "\n Your answer: ";
 }
 
 }
 while (play_again != 'y' && play_again != 'Y' && play_again != 'n' && play_again != 'N');
 // --- end of do/while loop for user's wrong answer ---
 
 system("clear");//clear the screen for begin another game or go to the final output
 
 }
 while (play_again == 'y' || play_again == 'Y');
 
 // ---- end of do/while loop for loop the whole game ----
 
 
 // ------ final output ------
 
 //output the number of losses and wins that the user had
 cout << "\n\t\t\t\t WINS:   |    LOSSES: " << endl;
 cout << "\n\t\t\t\t---------------------" << endl;
 cout << "\n\t\t\t\t   " << wins << "     |      " << losses << endl;
 
 //output the ASCII of the hagman
 cout << "\n\t\t\t\t\t " << "  ________   " << endl;
 cout << "\t\t\t\t\t " << "  |      |   " << endl;
 cout << "\t\t\t\t\t " << "  |      O  " << endl;
 cout << "\t\t\t\t\t " << "  |    - | - " << endl;
 cout << "\t\t\t\t\t " << "  |      |   " << endl;
 cout << "\t\t\t\t\t " << "  |    _ | _ " << endl;
 cout << "\t\t\t\t\t " << "  |          " << endl;
 cout << "\t\t\t\t\t " << "  |          " << endl;
 cout << "\t\t\t\t\t " << " ---         " << endl;
 
 
 //thank the user for playing the game and say goodbye
 cout << "\n\n\tThank you for playing Hangman! See you later!\n" << endl;
 
 // ------ end of final output ------
 
 return 0;
 
}
 
//function for find if the letter is in the word and to put it in the characterized word
int letterFill (char guess, string secretword, string &guessword)
{
  int matches = 0;
  int len=secretword.length();
  for (int i = 0; i< len; i++)
  {
    if (guess == guessword[i])
     return 0;
    if (guess == secretword[i])
    {
      guessword[i] = guess;
      matches++;
    }
 }
 return matches;
}